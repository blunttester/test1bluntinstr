<?php

defined( 'ABSPATH' ) or die;

$GLOBALS['processed_terms'] = array();
$GLOBALS['processed_posts'] = array();

require_once ABSPATH . 'wp-admin/includes/post.php';
require_once ABSPATH . 'wp-admin/includes/taxonomy.php';
require_once ABSPATH . 'wp-admin/includes/image.php';

function themify_import_post( $post ) {
	global $processed_posts, $processed_terms;

	if ( ! post_type_exists( $post['post_type'] ) ) {
		return;
	}

	/* Menu items don't have reliable post_title, skip the post_exists check */
	if( $post['post_type'] !== 'nav_menu_item' ) {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
		if ( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
			$processed_posts[ intval( $post['ID'] ) ] = intval( $post_exists );
			return;
		}
	}

	if( $post['post_type'] == 'nav_menu_item' ) {
		if( ! isset( $post['tax_input']['nav_menu'] ) || ! term_exists( $post['tax_input']['nav_menu'], 'nav_menu' ) ) {
			return;
		}
		$_menu_item_type = $post['meta_input']['_menu_item_type'];
		$_menu_item_object_id = $post['meta_input']['_menu_item_object_id'];

		if ( 'taxonomy' == $_menu_item_type && isset( $processed_terms[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_terms[ intval( $_menu_item_object_id ) ];
		} else if ( 'post_type' == $_menu_item_type && isset( $processed_posts[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_posts[ intval( $_menu_item_object_id ) ];
		} else if ( 'custom' != $_menu_item_type ) {
			// associated object is missing or not imported yet, we'll retry later
			// $missing_menu_items[] = $item;
			return;
		}
	}

	$post_parent = ( $post['post_type'] == 'nav_menu_item' ) ? $post['meta_input']['_menu_item_menu_item_parent'] : (int) $post['post_parent'];
	$post['post_parent'] = 0;
	if ( $post_parent ) {
		// if we already know the parent, map it to the new local ID
		if ( isset( $processed_posts[ $post_parent ] ) ) {
			if( $post['post_type'] == 'nav_menu_item' ) {
				$post['meta_input']['_menu_item_menu_item_parent'] = $processed_posts[ $post_parent ];
			} else {
				$post['post_parent'] = $processed_posts[ $post_parent ];
			}
		}
	}

	/**
	 * for hierarchical taxonomies, IDs must be used so wp_set_post_terms can function properly
	 * convert term slugs to IDs for hierarchical taxonomies
	 */
	if( ! empty( $post['tax_input'] ) ) {
		foreach( $post['tax_input'] as $tax => $terms ) {
			if( is_taxonomy_hierarchical( $tax ) ) {
				$terms = explode( ', ', $terms );
				$post['tax_input'][ $tax ] = array_map( 'themify_get_term_id_by_slug', $terms, array_fill( 0, count( $terms ), $tax ) );
			}
		}
	}

	$post['post_author'] = (int) get_current_user_id();
	$post['post_status'] = 'publish';

	$old_id = $post['ID'];

	unset( $post['ID'] );
	$post_id = wp_insert_post( $post, true );
	if( is_wp_error( $post_id ) ) {
		return false;
	} else {
		$processed_posts[ $old_id ] = $post_id;

		if( isset( $post['has_thumbnail'] ) && $post['has_thumbnail'] ) {
			$placeholder = themify_get_placeholder_image();
			if( ! is_wp_error( $placeholder ) ) {
				set_post_thumbnail( $post_id, $placeholder );
			}
		}

		return $post_id;
	}
}

function themify_get_placeholder_image() {
	static $placeholder_image = null;

	if( $placeholder_image == null ) {
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;
		$upload = wp_upload_bits( $post['post_name'] . '.jpg', null, $wp_filesystem->get_contents( THEMIFY_DIR . '/img/image-placeholder.jpg' ) );

		if ( $info = wp_check_filetype( $upload['file'] ) )
			$post['post_mime_type'] = $info['type'];
		else
			return new WP_Error( 'attachment_processing_error', __( 'Invalid file type', 'themify' ) );

		$post['guid'] = $upload['url'];
		$post_id = wp_insert_attachment( $post, $upload['file'] );
		wp_update_attachment_metadata( $post_id, wp_generate_attachment_metadata( $post_id, $upload['file'] ) );

		$placeholder_image = $post_id;
	}

	return $placeholder_image;
}

function themify_import_term( $term ) {
	global $processed_terms;

	if( $term_id = term_exists( $term['slug'], $term['taxonomy'] ) ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];
		if ( isset( $term['term_id'] ) )
			$processed_terms[ intval( $term['term_id'] ) ] = (int) $term_id;
		return (int) $term_id;
	}

	if ( empty( $term['parent'] ) ) {
		$parent = 0;
	} else {
		$parent = term_exists( $term['parent'], $term['taxonomy'] );
		if ( is_array( $parent ) ) $parent = $parent['term_id'];
	}

	$id = wp_insert_term( $term['name'], $term['taxonomy'], array(
		'parent' => $parent,
		'slug' => $term['slug'],
		'description' => $term['description'],
	) );
	if ( ! is_wp_error( $id ) ) {
		if ( isset( $term['term_id'] ) ) {
			$processed_terms[ intval($term['term_id']) ] = $id['term_id'];
			return $term['term_id'];
		}
	}

	return false;
}

function themify_get_term_id_by_slug( $slug, $tax ) {
	$term = get_term_by( 'slug', $slug, $tax );
	if( $term ) {
		return $term->term_id;
	}

	return false;
}

function themify_undo_import_term( $term ) {
	$term_id = term_exists( $term['slug'], $term['taxonomy'] );
	if ( $term_id ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];
		if ( isset( $term_id ) ) {
			wp_delete_term( $term_id, $term['taxonomy'] );
		}
	}
}

/**
 * Determine if a post exists based on title, content, and date
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param array $args array of database parameters to check
 * @return int Post ID if post exists, 0 otherwise.
 */
function themify_post_exists( $args = array() ) {
	global $wpdb;

	$query = "SELECT ID FROM $wpdb->posts WHERE 1=1";
	$db_args = array();

	foreach ( $args as $key => $value ) {
		$value = wp_unslash( sanitize_post_field( $key, $value, 0, 'db' ) );
		if( ! empty( $value ) ) {
			$query .= ' AND ' . $key . ' = %s';
			$db_args[] = $value;
		}
	}

	if ( !empty ( $args ) )
		return (int) $wpdb->get_var( $wpdb->prepare($query, $args) );

	return 0;
}

function themify_undo_import_post( $post ) {
	if( $post['post_type'] == 'nav_menu_item' ) {
		$post_exists = themify_post_exists( array(
			'post_name' => $post['post_name'],
			'post_modified' => $post['post_date'],
			'post_type' => 'nav_menu_item',
		) );
	} else {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
	}
	if( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
		/**
		 * check if the post has been modified, if so leave it be
		 *
		 * NOTE: posts are imported using wp_insert_post() which modifies post_modified field
		 * to be the same as post_date, hence to check if the post has been modified,
		 * the post_modified field is compared against post_date in the original post.
		 */
		if( $post['post_date'] == get_post_field( 'post_modified', $post_exists ) ) {
			wp_delete_post( $post_exists, true ); // true: bypass trash
		}
	}
}

function themify_do_demo_import() {

	if ( isset( $GLOBALS["ThemifyBuilder_Data_Manager"] ) ) {
		remove_action( "save_post", array( $GLOBALS["ThemifyBuilder_Data_Manager"], "save_builder_text_only"), 10, 3 );
	}
$term = array (
  'term_id' => 3,
  'name' => 'Blog',
  'slug' => 'blog',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 113,
  'name' => 'Images',
  'slug' => 'images',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 92,
  'name' => 'gifts',
  'slug' => 'gifts-2',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 93,
  'name' => 'food',
  'slug' => 'food-2',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 97,
  'name' => 'casual',
  'slug' => 'casual',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 98,
  'name' => 'bicycle',
  'slug' => 'bicycle',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 99,
  'name' => 'toys',
  'slug' => 'toys',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 100,
  'name' => 'sunglasses',
  'slug' => 'sunglasses',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 101,
  'name' => 'shoes',
  'slug' => 'shoes',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 102,
  'name' => 'cameras',
  'slug' => 'cameras',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 103,
  'name' => 'cake',
  'slug' => 'cake',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 104,
  'name' => 'cookies',
  'slug' => 'cookies',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 106,
  'name' => 'shop',
  'slug' => 'shop',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 107,
  'name' => 'fruits',
  'slug' => 'fruits',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 108,
  'name' => 'contest',
  'slug' => 'contest',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 109,
  'name' => 'sale',
  'slug' => 'sale',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 87,
  'name' => 'Food',
  'slug' => 'food',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 88,
  'name' => 'Gifts',
  'slug' => 'gifts',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 90,
  'name' => 'Clothes',
  'slug' => 'clothes',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 21,
  'name' => 'Black',
  'slug' => 'black',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 22,
  'name' => 'Blue',
  'slug' => 'blue',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 34,
  'name' => 'Green',
  'slug' => 'green',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 35,
  'name' => 'Indigo',
  'slug' => 'indigo',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 47,
  'name' => 'Orange',
  'slug' => 'orange',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 59,
  'name' => 'Red',
  'slug' => 'red',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 72,
  'name' => 'Violet',
  'slug' => 'violet',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 74,
  'name' => 'White',
  'slug' => 'white',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 79,
  'name' => 'Yellow',
  'slug' => 'yellow',
  'term_group' => 0,
  'taxonomy' => 'pa_color',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 40,
  'name' => 'Large',
  'slug' => 'large',
  'term_group' => 0,
  'taxonomy' => 'pa_size',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 42,
  'name' => 'Medium',
  'slug' => 'medium',
  'term_group' => 0,
  'taxonomy' => 'pa_size',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 66,
  'name' => 'Small',
  'slug' => 'small',
  'term_group' => 0,
  'taxonomy' => 'pa_size',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 77,
  'name' => 'X-Large',
  'slug' => 'x-large',
  'term_group' => 0,
  'taxonomy' => 'pa_size',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 110,
  'name' => '6',
  'slug' => '6',
  'term_group' => 0,
  'taxonomy' => 'pa_size',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 111,
  'name' => '7',
  'slug' => '7',
  'term_group' => 0,
  'taxonomy' => 'pa_size',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 112,
  'name' => '8',
  'slug' => '8',
  'term_group' => 0,
  'taxonomy' => 'pa_size',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 4,
  'name' => 'Main Nav',
  'slug' => 'main-nav',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$post = array (
  'ID' => 1389,
  'post_date' => '2012-12-17 17:27:23',
  'post_date_gmt' => '2012-12-17 17:27:23',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est. Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus. Aliquam euismod est quis ante fringilla egestas.

<strong>Vivamus nibh sapien, porttitor at dignissim a, commodo id dolor.</strong> Integer id libero non massa bibendum tempor. Sed sit amet nibh vel dui pulvinar convallis. Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus sit amet lacus augue. In lacinia, ligula nec ultrices mattis, mi elit aliquam nibh, non dignissim quam lectus nec felis.',
  'post_title' => 'Fruits and health',
  'post_excerpt' => '',
  'post_name' => 'fruits-and-health',
  'post_modified' => '2017-08-24 04:57:27',
  'post_modified_gmt' => '2017-08-24 04:57:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1389',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'fruits',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1394,
  'post_date' => '2012-12-17 17:30:11',
  'post_date_gmt' => '2012-12-17 17:30:11',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est. Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus. Aliquam euismod est quis ante fringilla egestas. Vivamus nibh sapien, porttitor at dignissim a, commodo id dolor. Integer id libero non massa bibendum tempor. Sed sit amet nibh vel dui pulvinar convallis. Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus sit amet lacus augue.

In lacinia, ligula nec ultrices mattis, mi elit aliquam nibh, non dignissim quam lectus nec felis.',
  'post_title' => 'Open 24/7',
  'post_excerpt' => '',
  'post_name' => 'open-247',
  'post_modified' => '2017-08-24 04:57:25',
  'post_modified_gmt' => '2017-08-24 04:57:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1394',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'shop',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1398,
  'post_date' => '2012-12-17 17:37:04',
  'post_date_gmt' => '2012-12-17 17:37:04',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est. Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus.

Aliquam euismod est quis ante fringilla egestas. Vivamus nibh sapien, porttitor at dignissim a, commodo id dolor. Integer id libero non massa bibendum tempor. Sed sit amet nibh vel dui pulvinar convallis. Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus sit amet lacus augue. In lacinia, ligula nec ultrices mattis, mi elit aliquam nibh, non dignissim quam lectus nec felis.',
  'post_title' => 'Winter Sale',
  'post_excerpt' => '',
  'post_name' => 'winter-sale',
  'post_modified' => '2017-08-24 04:57:23',
  'post_modified_gmt' => '2017-08-24 04:57:23',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1398',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'sale',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1401,
  'post_date' => '2012-12-17 17:39:20',
  'post_date_gmt' => '2012-12-17 17:39:20',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est. Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus. Aliquam euismod est quis ante fringilla egestas. Vivamus nibh sapien, porttitor at dignissim a, commodo id dolor. Integer id libero non massa bibendum tempor.
<h3>Sed sit amet nibh vel dui pulvinar convallis</h3>
Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus sit amet lacus augue. In lacinia, ligula nec ultrices mattis, mi elit aliquam nibh, non dignissim quam lectus nec felis.

Praesent quam arcu, dapibus ut elementum non, luctus ut quam. Nulla massa magna, tristique quis euismod non, tincidunt nec leo. Vivamus in ante ut arcu vulputate viverra at nec nisi. Curabitur id libero ac ligula auctor condimentum.',
  'post_title' => 'The cherry on top',
  'post_excerpt' => '',
  'post_name' => 'the-cherry-on-top',
  'post_modified' => '2017-08-24 04:57:22',
  'post_modified_gmt' => '2017-08-24 04:57:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1401',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'food-2',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1410,
  'post_date' => '2012-12-17 17:57:41',
  'post_date_gmt' => '2012-12-17 17:57:41',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est. Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus. Aliquam euismod est quis ante fringilla egestas.',
  'post_title' => 'Shop and win!',
  'post_excerpt' => '',
  'post_name' => 'shop-and-win',
  'post_modified' => '2017-08-24 04:57:19',
  'post_modified_gmt' => '2017-08-24 04:57:19',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1410',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'contest',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1414,
  'post_date' => '2012-12-17 18:00:42',
  'post_date_gmt' => '2012-12-17 18:00:42',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. <strong>Cras tincidunt rutrum risus, at ultrices odio consectetur ac.</strong> In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est.

Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus. Aliquam euismod est quis ante fringilla egestas.',
  'post_title' => 'More on tilt-shift photography',
  'post_excerpt' => '',
  'post_name' => 'more-on-tilt-shift-photography',
  'post_modified' => '2017-08-24 04:57:17',
  'post_modified_gmt' => '2017-08-24 04:57:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1414',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'lightbox_link' => 'https://themify.me/demo/themes/pinshop/files/2012/12/89287826.jpg',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'cameras',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1419,
  'post_date' => '2012-12-17 18:03:40',
  'post_date_gmt' => '2012-12-17 18:03:40',
  'post_content' => 'Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus.

Sed sit amet nibh vel dui pulvinar convallis. Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.',
  'post_title' => 'Fun with Cookies',
  'post_excerpt' => '',
  'post_name' => 'fun-with-cookies',
  'post_modified' => '2017-08-24 04:57:16',
  'post_modified_gmt' => '2017-08-24 04:57:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1419',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'external_link' => 'https://themify.me/',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'cookies',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1423,
  'post_date' => '2012-12-17 18:05:53',
  'post_date_gmt' => '2012-12-17 18:05:53',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est.
<p style="text-align: center;"><strong>Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est</strong></p>',
  'post_title' => 'Digital cameras sale',
  'post_excerpt' => '',
  'post_name' => 'digital-cameras-sale',
  'post_modified' => '2017-08-24 04:57:14',
  'post_modified_gmt' => '2017-08-24 04:57:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1423',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'cameras',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1427,
  'post_date' => '2012-12-17 18:16:10',
  'post_date_gmt' => '2012-12-17 18:16:10',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.

Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna. Suspendisse id erat vel est accumsan rutrum non vitae augue. Nulla euismod facilisis nulla eget gravida.',
  'post_title' => 'Latest cake recipes',
  'post_excerpt' => '',
  'post_name' => 'latest-cake-recipes',
  'post_modified' => '2017-08-24 04:57:12',
  'post_modified_gmt' => '2017-08-24 04:57:12',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1427',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'cake',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1430,
  'post_date' => '2012-12-17 18:17:01',
  'post_date_gmt' => '2012-12-17 18:17:01',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est.

Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est.',
  'post_title' => 'New arrival - Toys',
  'post_excerpt' => '',
  'post_name' => 'new-arrival-toys',
  'post_modified' => '2017-08-24 04:57:11',
  'post_modified_gmt' => '2017-08-24 04:57:11',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1430',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'external_link' => 'https://themify.me/',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'gifts-2, toys',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1434,
  'post_date' => '2012-12-17 18:20:27',
  'post_date_gmt' => '2012-12-17 18:20:27',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est. Quisque aliquet, ligula non pulvinar cursus, augue dui euismod est, et fermentum enim nulla sit amet tellus. Aliquam euismod est quis ante fringilla egestas.',
  'post_title' => 'New analog cameras available',
  'post_excerpt' => '',
  'post_name' => 'new-analog-cameras-available',
  'post_modified' => '2017-08-24 04:57:08',
  'post_modified_gmt' => '2017-08-24 04:57:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1434',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'lightbox_link' => 'https://themify.me/demo/themes/pinshop/files/2012/12/122608776.jpg',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'cameras',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1438,
  'post_date' => '2012-12-17 17:50:21',
  'post_date_gmt' => '2012-12-17 17:50:21',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac.

In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc.',
  'post_title' => 'Black, white and new',
  'post_excerpt' => '',
  'post_name' => 'black-white-and-new',
  'post_modified' => '2017-08-24 04:57:20',
  'post_modified_gmt' => '2017-08-24 04:57:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1438',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'shoes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1441,
  'post_date' => '2012-12-17 18:24:28',
  'post_date_gmt' => '2012-12-17 18:24:28',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Sunglasses with personality',
  'post_excerpt' => '',
  'post_name' => 'sunglasses-with-personality',
  'post_modified' => '2017-08-24 04:57:06',
  'post_modified_gmt' => '2017-08-24 04:57:06',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1441',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'external_link' => 'https://themify.me/',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'gifts-2, sunglasses',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1444,
  'post_date' => '2012-12-17 18:25:21',
  'post_date_gmt' => '2012-12-17 18:25:21',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt rutrum risus, at ultrices odio consectetur ac. In tristique faucibus facilisis. Suspendisse nec quam et augue tempus vehicula rutrum vel nunc. Suspendisse dui sem, hendrerit vulputate laoreet quis, facilisis sed est.',
  'post_title' => 'New toy provider',
  'post_excerpt' => '',
  'post_name' => 'new-toy-provider',
  'post_modified' => '2017-08-24 04:57:04',
  'post_modified_gmt' => '2017-08-24 04:57:04',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1444',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'lightbox_link' => 'https://themify.me/demo/themes/pinshop/files/2012/12/sb10067236av-001.jpg',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'gifts-2, toys',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1448,
  'post_date' => '2012-12-17 18:26:47',
  'post_date_gmt' => '2012-12-17 18:26:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.<!--more-->

Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Casual clothes ride',
  'post_excerpt' => '',
  'post_name' => 'casual-clothes-ride',
  'post_modified' => '2017-08-24 04:57:02',
  'post_modified_gmt' => '2017-08-24 04:57:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1448',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
    'post_tag' => 'bicycle, casual',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 6,
  'post_date' => '2008-06-11 20:22:47',
  'post_date_gmt' => '2008-06-11 20:22:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ac lobortis orci, a ornare dui. Phasellus consequat vulputate dignissim. Etiam condimentum aliquam augue, a ullamcorper erat facilisis et. Proin congue augue sit amet ligula dictum porta. Integer pharetra euismod velit ac laoreet. Ut dictum vitae ligula sed fermentum. Sed dapibus purus sit amet massa faucibus varius. Proin nec malesuada libero.',
  'post_title' => 'Butterfly Light',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ac lobortis orci...',
  'post_name' => 'butterfly-light',
  'post_modified' => '2017-08-24 04:57:37',
  'post_modified_gmt' => '2017-08-24 04:57:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=6',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 8,
  'post_date' => '2008-06-11 20:27:11',
  'post_date_gmt' => '2008-06-11 20:27:11',
  'post_content' => 'Integer ultrices turpis laoreet tellus venenatis, sed luctus libero gravida. Vestibulum eu hendrerit eros. Quisque eget luctus turpis, eget cursus velit. Nullam auctor ligula velit, fringilla molestie elit mattis et. Donec volutpat adipiscing urna, at egestas odio venenatis aliquet.',
  'post_title' => 'Sunset',
  'post_excerpt' => 'Integer ultrices turpis laoreet tellus venenatis, sed luctus libero gravida.',
  'post_name' => 'sunset',
  'post_modified' => '2017-08-24 04:57:35',
  'post_modified_gmt' => '2017-08-24 04:57:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=8',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 22,
  'post_date' => '2008-06-11 20:38:30',
  'post_date_gmt' => '2008-06-11 20:38:30',
  'post_content' => 'Vestibulum a quam nisl. Nam sagittis neque erat, sed egestas urna facilisis et. Cras interdum imperdiet est, ac porttitor sapien porttitor id. Aenean semper congue dolor, non malesuada sapien. Sed neque diam, cursus eget eros at, pretium sagittis ligula. Sed pretium urna vitae velit pharetra',
  'post_title' => 'Late Stroll',
  'post_excerpt' => 'Vestibulum a quam nisl. Nam sagittis neque erat, sed egestas urna facilisis et.',
  'post_name' => 'late-stroll',
  'post_modified' => '2017-08-24 04:57:34',
  'post_modified_gmt' => '2017-08-24 04:57:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=22',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 25,
  'post_date' => '2008-06-11 20:41:16',
  'post_date_gmt' => '2008-06-11 20:41:16',
  'post_content' => 'Etiam ipsum ligula, mollis eu vestibulum id, ornare vel nibh. Sed sollicitudin, arcu non auctor pulvinar, velit eros viverra sapien, a mattis sem tortor sed arcu. Aenean gravida tincidunt commodo. In felis nunc, ultricies vel congue nec, congue vitae lacus.',
  'post_title' => 'Empty House',
  'post_excerpt' => 'Etiam ipsum ligula, mollis eu vestibulum id, ornare vel nibh. Sed sollicitudin, arcu non...',
  'post_name' => 'empty-house',
  'post_modified' => '2017-08-24 04:57:33',
  'post_modified_gmt' => '2017-08-24 04:57:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=25',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 28,
  'post_date' => '2008-06-11 20:42:29',
  'post_date_gmt' => '2008-06-11 20:42:29',
  'post_content' => 'Vestibulum malesuada neque nec hendrerit lobortis. Maecenas erat diam, fringilla et hendrerit eu, laoreet vel quam. Integer sollicitudin nec eros a fringilla. Mauris sed velit sapien. Pellentesque habitant morbi tristique senectus et netus et malesuada.',
  'post_title' => 'Sweet Tooth',
  'post_excerpt' => 'Vestibulum malesuada neque nec hendrerit lobortis. Maecenas erat diam, fringilla...',
  'post_name' => 'sweet-tooth',
  'post_modified' => '2017-08-24 04:57:32',
  'post_modified_gmt' => '2017-08-24 04:57:32',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=28',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_meta' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1271,
  'post_date' => '2012-12-05 23:36:05',
  'post_date_gmt' => '2012-12-05 23:36:05',
  'post_content' => '',
  'post_title' => 'Shop',
  'post_excerpt' => '',
  'post_name' => 'shop',
  'post_modified' => '2017-08-24 04:58:54',
  'post_modified_gmt' => '2017-08-24 04:58:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/shop/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1273,
  'post_date' => '2012-12-05 23:36:05',
  'post_date_gmt' => '2012-12-05 23:36:05',
  'post_content' => '[woocommerce_checkout]',
  'post_title' => 'Checkout',
  'post_excerpt' => '',
  'post_name' => 'checkout',
  'post_modified' => '2017-08-24 04:58:47',
  'post_modified_gmt' => '2017-08-24 04:58:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/checkout/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 121,
  'post_date' => '2012-02-27 06:43:35',
  'post_date_gmt' => '2012-02-27 06:43:35',
  'post_content' => '',
  'post_title' => 'Blog',
  'post_excerpt' => '',
  'post_name' => 'blog',
  'post_modified' => '2017-08-24 04:58:27',
  'post_modified_gmt' => '2017-08-24 04:58:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopdock/?page_id=121',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'posts_per_page' => '4',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 123,
  'post_date' => '2012-02-27 06:44:14',
  'post_date_gmt' => '2012-02-27 06:44:14',
  'post_content' => '',
  'post_title' => 'Blog - 4 Columns',
  'post_excerpt' => '',
  'post_name' => 'blog-4-columns',
  'post_modified' => '2017-10-30 13:54:46',
  'post_modified_gmt' => '2017-10-30 13:54:46',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/shopdock/?page_id=123',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'grid4',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 126,
  'post_date' => '2012-02-27 06:44:43',
  'post_date_gmt' => '2012-02-27 06:44:43',
  'post_content' => '',
  'post_title' => 'Blog - 3 Columns',
  'post_excerpt' => '',
  'post_name' => 'blog-3-columns',
  'post_modified' => '2017-08-24 04:58:30',
  'post_modified_gmt' => '2017-08-24 04:58:30',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/shopdock/?page_id=126',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'grid3',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 128,
  'post_date' => '2012-02-27 06:45:03',
  'post_date_gmt' => '2012-02-27 06:45:03',
  'post_content' => '',
  'post_title' => 'Blog - 2 Columns',
  'post_excerpt' => '',
  'post_name' => 'blog-2-columns',
  'post_modified' => '2017-08-24 04:58:29',
  'post_modified_gmt' => '2017-08-24 04:58:29',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/shopdock/?page_id=128',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'grid2',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 139,
  'post_date' => '2012-02-27 06:50:25',
  'post_date_gmt' => '2012-02-27 06:50:25',
  'post_content' => 'Download this contact plugin: <a href="http://wordpress.org/extend/plugins/contact-form-7">Contact Form 7</a>.

[contact-form-7 id="141" title="Untitled"]',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2017-08-24 04:58:49',
  'post_modified_gmt' => '2017-08-24 04:58:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopdock/?page_id=139',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 146,
  'post_date' => '2012-02-27 06:52:29',
  'post_date_gmt' => '2012-02-27 06:52:29',
  'post_content' => '',
  'post_title' => 'Map',
  'post_excerpt' => '',
  'post_name' => 'map',
  'post_modified' => '2017-08-25 02:39:32',
  'post_modified_gmt' => '2017-08-25 02:39:32',
  'post_content_filtered' => '',
  'post_parent' => 139,
  'guid' => 'https://themify.me/demo/themes/shopdock/?page_id=146',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col3-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"map\\",\\"mod_settings\\":{\\"map_display_type\\":\\"dynamic\\",\\"address_map\\":\\"Yonge St. and Eglinton Ave, Toronto, Ontario, Canada\\",\\"zoom_map\\":\\"15\\",\\"w_map\\":\\"100\\",\\"unit_w\\":\\"%\\",\\"h_map\\":\\"600\\",\\"unit_h\\":\\"px\\",\\"b_style_map\\":\\"solid\\",\\"type_map\\":\\"ROADMAP\\",\\"scrollwheel_map\\":\\"disable\\",\\"draggable_map\\":\\"enable\\",\\"draggable_disable_mobile_map\\":\\"yes\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_top_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_left_style\\":\\"solid\\",\\"checkbox_border_apply_all\\":\\"border\\"}}],\\"styling\\":[]},{\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Direction</h3><p>We are located at Aliquam faucibus turpis at libero consectetur euismod. Nam nunc lectus, congue non egestas quis, condimentum ut arcu. Nulla placerat, tortor non egestas rutrum, mi turpis adipiscing dui, et mollis turpis tortor vel orci. Cras a fringilla nunc. Suspendisse volutpat, eros congue scelerisque iaculis, magna odio sodales dui, vitae vulputate elit metus ac arcu.</p><h3>Address</h3><p>123 Street Name,<br /> City, Province<br /> 23446</p><h3>Phone</h3><p>236-298-2828</p><h3>Hours</h3><p>Mon - Fri : 11:00am - 10:00pm<br /> Sat : 11:00am - 2:00pm<br /> Sun : 12:00am - 11:00pm</p>\\",\\"column_divider_style\\":\\"solid\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_top_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_left_style\\":\\"solid\\",\\"checkbox_border_apply_all\\":\\"border\\"}}],\\"styling\\":[]}],\\"column_alignment\\":\\"\\",\\"styling\\":[]},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[]}],\\"styling\\":[]}]',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 152,
  'post_date' => '2012-02-27 06:53:58',
  'post_date_gmt' => '2012-02-27 06:53:58',
  'post_content' => '<h3>Buttons</h3>
[button style="orange" link="https://themify.me"]Orange[/button] [button style="blue"]Blue[/button] [button style="pink"]Pink[/button] [button style="green"]Green[/button] [button style="red"]Red[/button] [button style="black"]Black[/button]

[hr]

[button style="small"]Small[/button]

[button]Default[/button]

[button style="large"]Large[/button] [button style="xlarge"]Xlarge[/button]

[hr]

[button style="orange small"]Orange Small[/button] [button style="blue"]Blue[/button] [button style="green large"]Green Large[/button] [button style="red xlarge"]Red Xlarge[/button]

[hr]
<h3>Columns</h3>
[col grid="2-1 first"]
<h4>col 2-1</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eg.

[/col]

[col grid="2-1"]
<h4>col 2-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.

[/col]

[hr]

[col grid="3-1 first"]
<h4>col 3-1</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eg.

[/col]

[col grid="3-1"]
<h4>col 3-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.

[/col]

[col grid="3-1"]
<h4>col 3-1</h4>
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit.

[/col]

[hr]

[col grid="4-1 first"]
<h4>col 4-1</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget co.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit diam.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Donec porttitor hendrerit diam et blandit. Curabitur vel risus eros, sed eleifend arcu. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[hr]

[col grid="4-2 first"]
<h4>col 4-2</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget cout rhoncus turpis augue vitae libero.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit diam.

[/col]
<h3>Horizontal Rules</h3>
[hr]

[hr color="pink"]

[hr color="red"]

[hr color="light-gray"]

[hr color="dark-gray"]

[hr color="black"]

[hr color="orange"]

[hr color="yellow"]

[hr color="white"]
<h3>Quote</h3>
[quote]Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu. Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta enim vel consectetur. Etiam orci eros, blandit nec egestas eget, pharetra eget leo. Morbi lobortis adipiscing massa tincidunt dignissim. Nulla lobortis laoreet risus, tempor accumsan sem congue vitae. Cras laoreet hendrerit erat, id porttitor nunc blandit adipiscing. [/quote]
<h3>Map</h3>
[map address="Yonge St. and Eglinton Ave, Toronto, Ontario, Canada" width=100% height=400px]',
  'post_title' => 'Shortcodes',
  'post_excerpt' => '',
  'post_name' => 'shortcodes',
  'post_modified' => '2017-08-24 04:58:56',
  'post_modified_gmt' => '2017-08-24 04:58:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopdock/?page_id=152',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1288,
  'post_date' => '2012-12-10 22:04:27',
  'post_date_gmt' => '2012-12-10 22:04:27',
  'post_content' => '',
  'post_title' => 'Full - Grid2',
  'post_excerpt' => '',
  'post_name' => 'full-grid2',
  'post_modified' => '2017-08-24 04:58:34',
  'post_modified_gmt' => '2017-08-24 04:58:34',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?page_id=1288',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'grid2',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1285,
  'post_date' => '2012-12-10 22:00:59',
  'post_date_gmt' => '2012-12-10 22:00:59',
  'post_content' => '',
  'post_title' => 'Full - Grid3',
  'post_excerpt' => '',
  'post_name' => 'full-grid3',
  'post_modified' => '2017-08-24 04:58:35',
  'post_modified_gmt' => '2017-08-24 04:58:35',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?page_id=1285',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'grid3',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1282,
  'post_date' => '2012-12-10 22:00:38',
  'post_date_gmt' => '2012-12-10 22:00:38',
  'post_content' => '',
  'post_title' => 'Full - Grid4',
  'post_excerpt' => '',
  'post_name' => 'full-grid4',
  'post_modified' => '2017-08-24 04:58:37',
  'post_modified_gmt' => '2017-08-24 04:58:37',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?page_id=1282',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'grid4',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1274,
  'post_date' => '2012-12-05 23:36:05',
  'post_date_gmt' => '2012-12-05 23:36:05',
  'post_content' => '[woocommerce_order_tracking]',
  'post_title' => 'Track your order',
  'post_excerpt' => '',
  'post_name' => 'order-tracking',
  'post_modified' => '2017-08-24 04:58:58',
  'post_modified_gmt' => '2017-08-24 04:58:58',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/order-tracking/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1275,
  'post_date' => '2012-12-05 23:36:05',
  'post_date_gmt' => '2012-12-05 23:36:05',
  'post_content' => '[woocommerce_my_account]',
  'post_title' => 'My Account',
  'post_excerpt' => '',
  'post_name' => 'my-account',
  'post_modified' => '2017-08-24 04:58:52',
  'post_modified_gmt' => '2017-08-24 04:58:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/my-account/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1272,
  'post_date' => '2012-12-05 23:36:05',
  'post_date_gmt' => '2012-12-05 23:36:05',
  'post_content' => '[woocommerce_cart]',
  'post_title' => 'Cart',
  'post_excerpt' => '',
  'post_name' => 'cart',
  'post_modified' => '2017-08-24 04:58:44',
  'post_modified_gmt' => '2017-08-24 04:58:44',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/cart/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'default',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1451,
  'post_date' => '2012-12-17 20:05:06',
  'post_date_gmt' => '2012-12-17 20:05:06',
  'post_content' => '',
  'post_title' => 'Left Sidebar - Large Thumb',
  'post_excerpt' => '',
  'post_name' => 'left-sidebar-large-thumb',
  'post_modified' => '2017-08-24 04:58:39',
  'post_modified_gmt' => '2017-08-24 04:58:39',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?page_id=1451',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar1 sidebar-left',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-large-image',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'hide_meta' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1293,
  'post_date' => '2012-12-11 19:39:22',
  'post_date_gmt' => '2012-12-11 19:39:22',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Man in blue jeans',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'man-in-blue-jeans',
  'post_modified' => '2012-12-21 01:16:34',
  'post_modified_gmt' => '2012-12-21 01:16:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1293',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1294',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/134510511.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1356054620:32',
    'total_sales' => '0',
    '_sale_price' => '50',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
      'pa_size' => 
      array (
        'name' => 'pa_size',
        'value' => '',
        'position' => '2',
        'is_visible' => 0,
        'is_variation' => 1,
        'is_taxonomy' => 1,
      ),
      'pa_color' => 
      array (
        'name' => 'pa_color',
        'value' => '',
        'position' => '3',
        'is_visible' => 0,
        'is_variation' => 1,
        'is_taxonomy' => 1,
      ),
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '50',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_min_variation_price' => '45',
    '_max_variation_price' => '55',
    '_min_variation_regular_price' => '45',
    '_max_variation_regular_price' => '55',
    '_default_attributes' => 
    array (
      'pa_size' => 'x-large',
    ),
    '_wp_old_slug' => 'lorem-ipsum-2',
    '_post_image_attach_id' => '1294',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
    'pa_color' => 'yellow, white, violet, red, orange, indigo, green, blue, black',
    'pa_size' => 'x-large, small, medium, large',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1295,
  'post_date' => '2012-12-11 19:44:34',
  'post_date_gmt' => '2012-12-11 19:44:34',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Bath Cosmethics',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'bath-cosmethics',
  'post_modified' => '2012-12-11 20:01:55',
  'post_modified_gmt' => '2012-12-11 20:01:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1295',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256115:32',
    '_thumbnail_id' => '1296',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/bath-cosmethics.jpg',
    'total_sales' => '1',
    '_regular_price' => '16',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '16',
    '_stock' => '0',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1296',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355256115:32\\"],\\"_thumbnail_id\\":[\\"1296\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/bath-cosmethics.jpg\\"],\\"total_sales\\":[\\"1\\"],\\"_regular_price\\":[\\"16\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"16\\"],\\"_stock\\":[\\"0\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1296\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1297,
  'post_date' => '2012-12-11 19:47:00',
  'post_date_gmt' => '2012-12-11 19:47:00',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_title' => 'Bagels',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'bagels',
  'post_modified' => '2012-12-11 19:47:00',
  'post_modified_gmt' => '2012-12-11 19:47:00',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1297',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355255124:32',
    '_thumbnail_id' => '1298',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/bread.jpg',
    'total_sales' => '1',
    '_regular_price' => '0.30',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '0.30',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1298',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355255124:32\\"],\\"_thumbnail_id\\":[\\"1298\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/bread.jpg\\"],\\"total_sales\\":[\\"1\\"],\\"_regular_price\\":[\\"0.30\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"0.30\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1298\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1318,
  'post_date' => '2012-12-11 20:10:30',
  'post_date_gmt' => '2012-12-11 20:10:30',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.

Suspendisse id erat vel est accumsan rutrum non vitae augue. Nulla euismod facilisis nulla eget gravida. Duis placerat ultrices consectetur. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Integer et nisi arcu, quis ultricies massa. Nulla facilisi. Pellentesque leo dolor, ultrices et convallis id, tincidunt eget dui.',
  'post_title' => 'Digital Camera',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'digital-camera',
  'post_modified' => '2012-12-11 20:10:30',
  'post_modified_gmt' => '2012-12-11 20:10:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1318',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256540:32',
    '_thumbnail_id' => '1319',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/digital-camera.jpg',
    'total_sales' => '2',
    '_regular_price' => '320',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '320',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1319',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355256540:32\\"],\\"_thumbnail_id\\":[\\"1319\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/digital-camera.jpg\\"],\\"total_sales\\":[\\"2\\"],\\"_regular_price\\":[\\"320\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"320\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1319\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1291,
  'post_date' => '2012-12-11 19:37:39',
  'post_date_gmt' => '2012-12-11 19:37:39',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Man in casual outfit',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'man-in-casual-outfit',
  'post_modified' => '2012-12-12 01:30:50',
  'post_modified_gmt' => '2012-12-12 01:30:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1291',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1292',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/121355038.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1355275772:32',
    'total_sales' => '0',
    '_regular_price' => '20',
    '_sale_price' => '15',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '15',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_wp_old_slug' => 'lorem-ipsum',
    '_post_image_attach_id' => '1292',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_thumbnail_id\\":[\\"1292\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/121355038.jpg\\"],\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355275772:32\\"],\\"total_sales\\":[\\"0\\"],\\"_regular_price\\":[\\"20\\"],\\"_sale_price\\":[\\"15\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"15\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_wp_old_slug\\":[\\"lorem-ipsum\\"],\\"_post_image_attach_id\\":[\\"1292\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1299,
  'post_date' => '2012-12-11 19:48:17',
  'post_date_gmt' => '2012-12-11 19:48:17',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Apple Cake',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'apple-cake',
  'post_modified' => '2015-05-04 23:08:40',
  'post_modified_gmt' => '2015-05-04 23:08:40',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1299',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '113',
    '_edit_lock' => '1431450015:8',
    '_thumbnail_id' => '1300',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/cake.jpg',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
      'pa_size' => 
      array (
        'name' => 'pa_size',
        'value' => '',
        'position' => '0',
        'is_visible' => 0,
        'is_variation' => 1,
        'is_taxonomy' => 1,
      ),
      'pa_color' => 
      array (
        'name' => 'pa_color',
        'value' => '',
        'position' => '1',
        'is_visible' => 1,
        'is_variation' => 1,
        'is_taxonomy' => 1,
      ),
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '20',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_min_variation_price' => '20',
    '_max_variation_price' => '30',
    '_min_variation_regular_price' => '20',
    '_max_variation_regular_price' => '30',
    '_default_attributes' => 
    array (
    ),
    '_min_price_variation_id' => '1549',
    '_max_price_variation_id' => '1547',
    '_min_regular_price_variation_id' => '1549',
    '_max_regular_price_variation_id' => '1547',
    '_post_image_attach_id' => '1300',
    '_product_image_gallery' => '1574,1575',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'variable',
    'product_cat' => 'food',
    'pa_color' => 'white, indigo',
    'pa_size' => 'small, medium, large',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1302,
  'post_date' => '2012-12-11 19:50:47',
  'post_date_gmt' => '2012-12-11 19:50:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Mountain Cake',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'mountain-cake',
  'post_modified' => '2012-12-11 19:51:04',
  'post_modified_gmt' => '2012-12-11 19:51:04',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1302',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355255367:32',
    'total_sales' => '7',
    '_regular_price' => '20',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '20',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_thumbnail_id' => '1303',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/cake2.jpg',
    '_post_image_attach_id' => '1303',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355255367:32\\"],\\"total_sales\\":[\\"7\\"],\\"_regular_price\\":[\\"20\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"20\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_thumbnail_id\\":[\\"1303\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/cake2.jpg\\"],\\"_post_image_attach_id\\":[\\"1303\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1304,
  'post_date' => '2012-12-11 19:52:19',
  'post_date_gmt' => '2012-12-11 19:52:19',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Roses Cake',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'roses-cake',
  'post_modified' => '2012-12-11 19:52:19',
  'post_modified_gmt' => '2012-12-11 19:52:19',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1304',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1305',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/cake3.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1355255449:32',
    'total_sales' => '1',
    '_regular_price' => '20',
    '_sale_price' => '15',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '15',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1305',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1306,
  'post_date' => '2012-12-11 19:54:31',
  'post_date_gmt' => '2012-12-11 19:54:31',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Candle',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'candle',
  'post_modified' => '2013-02-05 23:10:56',
  'post_modified_gmt' => '2013-02-05 23:10:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1306',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1360105897:32',
    '_thumbnail_id' => '1307',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/candle.jpg',
    'total_sales' => '4',
    '_regular_price' => '5',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '5',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1307',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1308,
  'post_date' => '2012-12-11 19:55:34',
  'post_date_gmt' => '2012-12-11 19:55:34',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Cauliflower',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'cauliflower',
  'post_modified' => '2012-12-11 19:55:34',
  'post_modified_gmt' => '2012-12-11 19:55:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1308',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355255641:32',
    '_thumbnail_id' => '1309',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/cauliflower.jpg',
    'total_sales' => '1',
    '_regular_price' => '0.70',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '0.70',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1309',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1310,
  'post_date' => '2012-12-11 19:58:19',
  'post_date_gmt' => '2012-12-11 19:58:19',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Cosmetics',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'cosmetics',
  'post_modified' => '2012-12-11 19:58:19',
  'post_modified_gmt' => '2012-12-11 19:58:19',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1310',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355255806:32',
    '_thumbnail_id' => '1311',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/cosmetics.jpg',
    'total_sales' => '1',
    '_regular_price' => '30',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '30',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1311',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1312,
  'post_date' => '2012-12-11 20:01:18',
  'post_date_gmt' => '2012-12-11 20:01:18',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus.',
  'post_title' => 'Cosmetics & Perfume',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'cosmetics-perfume',
  'post_modified' => '2012-12-11 20:01:18',
  'post_modified_gmt' => '2012-12-11 20:01:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1312',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355255984:32',
    '_thumbnail_id' => '1313',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/cosmetics2.jpg',
    'total_sales' => '0',
    '_regular_price' => '50',
    '_sale_price' => '30',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '30',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1313',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1314,
  'post_date' => '2012-12-11 20:05:26',
  'post_date_gmt' => '2012-12-11 20:05:26',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_title' => 'Cupcakes & Donuts',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'cupcakes-donuts',
  'post_modified' => '2012-12-11 20:05:26',
  'post_modified_gmt' => '2012-12-11 20:05:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1314',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256227:32',
    '_thumbnail_id' => '1315',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/cupcakes-and-donuts.jpg',
    'total_sales' => '1',
    '_regular_price' => '1',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '1',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1315',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1316,
  'post_date' => '2012-12-11 20:07:11',
  'post_date_gmt' => '2012-12-11 20:07:11',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna.',
  'post_title' => 'Denim Pants',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'denim-pants',
  'post_modified' => '2012-12-21 01:16:50',
  'post_modified_gmt' => '2012-12-21 01:16:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1316',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1317',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/denim-pants.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1356052589:32',
    'total_sales' => '2',
    '_regular_price' => '50',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
      'pa_size' => 
      array (
        'name' => 'pa_size',
        'value' => '',
        'position' => '2',
        'is_visible' => 0,
        'is_variation' => 1,
        'is_taxonomy' => 1,
      ),
      'pa_color' => 
      array (
        'name' => 'pa_color',
        'value' => '',
        'position' => '3',
        'is_visible' => 0,
        'is_variation' => 1,
        'is_taxonomy' => 1,
      ),
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '50',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_min_variation_price' => '45',
    '_max_variation_price' => '50',
    '_min_variation_regular_price' => '45',
    '_max_variation_regular_price' => '50',
    '_default_attributes' => 
    array (
      'pa_size' => 'large',
    ),
    '_post_image_attach_id' => '1317',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
    'pa_color' => 'yellow, white, violet, red, orange, indigo, green, blue, black',
    'pa_size' => 'x-large, small, medium, large',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1320,
  'post_date' => '2012-12-11 20:11:47',
  'post_date_gmt' => '2012-12-11 20:11:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna. Suspendisse id erat vel est accumsan rutrum non vitae augue. Nulla euismod facilisis nulla eget gravida.',
  'post_title' => 'Another Digital Camera',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'another-digital-camera',
  'post_modified' => '2012-12-11 20:11:47',
  'post_modified_gmt' => '2012-12-11 20:11:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1320',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256609:32',
    '_thumbnail_id' => '1321',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/digital-camera2.jpg',
    'total_sales' => '9',
    '_regular_price' => '280',
    '_sale_price' => '200',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '200',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1321',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1322,
  'post_date' => '2012-12-11 20:13:27',
  'post_date_gmt' => '2012-12-11 20:13:27',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_title' => 'Dog Clothes - Pink',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_name' => 'dog-clothes-pink',
  'post_modified' => '2012-12-11 20:13:27',
  'post_modified_gmt' => '2012-12-11 20:13:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1322',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256732:32',
    '_thumbnail_id' => '1323',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/dog-with-clothes.jpg',
    'total_sales' => '1',
    '_regular_price' => '50',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '50',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1323',
    '_wc_rating_count' => 
    array (
      4 => '1',
    ),
    '_wc_average_rating' => '4.00',
    '_wc_review_count' => '1',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355256732:32\\"],\\"_thumbnail_id\\":[\\"1323\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/dog-with-clothes.jpg\\"],\\"total_sales\\":[\\"1\\"],\\"_regular_price\\":[\\"50\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"yes\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"50\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1323\\"],\\"_wc_rating_count\\":[\\"a:1:{i:4;s:1:\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\";}\\"],\\"_wc_average_rating\\":[\\"4.00\\"],\\"_wc_review_count\\":[\\"1\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured, rated-4',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1324,
  'post_date' => '2012-12-11 20:15:15',
  'post_date_gmt' => '2012-12-11 20:15:15',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.

Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna. Suspendisse id erat vel est accumsan rutrum non vitae augue. Nulla euismod facilisis nulla eget gravida.',
  'post_title' => 'Golf Clubs',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_name' => 'golf-clubs',
  'post_modified' => '2012-12-11 20:15:15',
  'post_modified_gmt' => '2012-12-11 20:15:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1324',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256819:32',
    '_thumbnail_id' => '1325',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/golf-clubs.jpg',
    'total_sales' => '1',
    '_regular_price' => '200',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '200',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1325',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1326,
  'post_date' => '2012-12-11 20:16:59',
  'post_date_gmt' => '2012-12-11 20:16:59',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus.

Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna. Suspendisse id erat vel est accumsan rutrum non vitae augue. Nulla euismod facilisis nulla eget gravida.',
  'post_title' => 'Doggy Accessories',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'doggy-accessories',
  'post_modified' => '2012-12-11 20:16:59',
  'post_modified_gmt' => '2012-12-11 20:16:59',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1326',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256922:32',
    '_thumbnail_id' => '1327',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/hip-dog.jpg',
    'total_sales' => '0',
    '_regular_price' => '30',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '30',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1327',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1328,
  'post_date' => '2012-12-11 20:18:08',
  'post_date_gmt' => '2012-12-11 20:18:08',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_title' => 'Keychane Sneaker',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'keychane-sneaker',
  'post_modified' => '2012-12-11 20:18:08',
  'post_modified_gmt' => '2012-12-11 20:18:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1328',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355256985:32',
    '_thumbnail_id' => '1329',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/keychane-sneaker.jpg',
    'total_sales' => '5',
    '_regular_price' => '5',
    '_sale_price' => '2',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '2',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1329',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355256985:32\\"],\\"_thumbnail_id\\":[\\"1329\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/keychane-sneaker.jpg\\"],\\"total_sales\\":[\\"5\\"],\\"_regular_price\\":[\\"5\\"],\\"_sale_price\\":[\\"2\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"yes\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"2\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1329\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1330,
  'post_date' => '2012-12-11 20:20:46',
  'post_date_gmt' => '2012-12-11 20:20:46',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien.

Curabitur sed tellus libero.',
  'post_title' => 'Black Shoes',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_name' => 'black-shoes',
  'post_modified' => '2013-11-01 00:00:06',
  'post_modified_gmt' => '2013-11-01 00:00:06',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1330',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '8',
    '_edit_lock' => '1383264470:8',
    '_thumbnail_id' => '1331',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/ladies-shoes.jpg',
    'total_sales' => '2',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
      'pa_size' => 
      array (
        'name' => 'pa_size',
        'value' => '',
        'position' => '0',
        'is_visible' => 0,
        'is_variation' => 1,
        'is_taxonomy' => 1,
      ),
      'pa_color' => 
      array (
        'name' => 'pa_color',
        'value' => '',
        'position' => '1',
        'is_visible' => 0,
        'is_variation' => 0,
        'is_taxonomy' => 1,
      ),
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '45',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_min_variation_price' => '45',
    '_max_variation_price' => '50',
    '_min_variation_regular_price' => '45',
    '_max_variation_regular_price' => '50',
    '_default_attributes' => 
    array (
      'pa_size' => '7',
    ),
    '_min_price_variation_id' => '1546',
    '_max_price_variation_id' => '1545',
    '_min_regular_price_variation_id' => '1546',
    '_max_regular_price_variation_id' => '1545',
    '_post_image_attach_id' => '1331',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"8\\"],\\"_edit_lock\\":[\\"1383264470:8\\"],\\"_thumbnail_id\\":[\\"1331\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/ladies-shoes.jpg\\"],\\"total_sales\\":[\\"2\\"],\\"_regular_price\\":[\\"\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:2:{s:7:\\\\\\\\\\\\\\"pa_size\\\\\\\\\\\\\\";a:6:{s:4:\\\\\\\\\\\\\\"name\\\\\\\\\\\\\\";s:7:\\\\\\\\\\\\\\"pa_size\\\\\\\\\\\\\\";s:5:\\\\\\\\\\\\\\"value\\\\\\\\\\\\\\";s:0:\\\\\\\\\\\\\\"\\\\\\\\\\\\\\";s:8:\\\\\\\\\\\\\\"position\\\\\\\\\\\\\\";s:1:\\\\\\\\\\\\\\"0\\\\\\\\\\\\\\";s:10:\\\\\\\\\\\\\\"is_visible\\\\\\\\\\\\\\";i:0;s:12:\\\\\\\\\\\\\\"is_variation\\\\\\\\\\\\\\";i:1;s:11:\\\\\\\\\\\\\\"is_taxonomy\\\\\\\\\\\\\\";i:1;}s:8:\\\\\\\\\\\\\\"pa_color\\\\\\\\\\\\\\";a:6:{s:4:\\\\\\\\\\\\\\"name\\\\\\\\\\\\\\";s:8:\\\\\\\\\\\\\\"pa_color\\\\\\\\\\\\\\";s:5:\\\\\\\\\\\\\\"value\\\\\\\\\\\\\\";s:0:\\\\\\\\\\\\\\"\\\\\\\\\\\\\\";s:8:\\\\\\\\\\\\\\"position\\\\\\\\\\\\\\";s:1:\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\";s:10:\\\\\\\\\\\\\\"is_visible\\\\\\\\\\\\\\";i:0;s:12:\\\\\\\\\\\\\\"is_variation\\\\\\\\\\\\\\";i:0;s:11:\\\\\\\\\\\\\\"is_taxonomy\\\\\\\\\\\\\\";i:1;}}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"45\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_min_variation_price\\":[\\"45\\"],\\"_max_variation_price\\":[\\"50\\"],\\"_min_variation_regular_price\\":[\\"45\\"],\\"_max_variation_regular_price\\":[\\"50\\"],\\"_min_variation_sale_price\\":[\\"\\"],\\"_max_variation_sale_price\\":[\\"\\"],\\"_default_attributes\\":[\\"a:1:{s:7:\\\\\\\\\\\\\\"pa_size\\\\\\\\\\\\\\";s:1:\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\";}\\"],\\"_product_image_gallery\\":[\\"\\"],\\"_sold_individually\\":[\\"\\"],\\"_min_price_variation_id\\":[\\"1546\\"],\\"_max_price_variation_id\\":[\\"1545\\"],\\"_min_regular_price_variation_id\\":[\\"1546\\"],\\"_max_regular_price_variation_id\\":[\\"1545\\"],\\"_min_sale_price_variation_id\\":[\\"\\"],\\"_max_sale_price_variation_id\\":[\\"\\"],\\"_post_image_attach_id\\":[\\"1331\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'variable',
    'product_cat' => 'gifts',
    'pa_color' => 'white, red, black',
    'pa_size' => '8, 7, 6',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1332,
  'post_date' => '2012-12-11 20:22:10',
  'post_date_gmt' => '2012-12-11 20:22:10',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_title' => 'Man in black suit',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'man-in-black-suit',
  'post_modified' => '2012-12-12 01:32:24',
  'post_modified_gmt' => '2012-12-12 01:32:24',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1332',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1333',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/man-in-suit.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1355275836:32',
    'total_sales' => '0',
    '_regular_price' => '150',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '150',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_wp_old_slug' => 'lorem-ipsum-3',
    '_post_image_attach_id' => '1333',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1334,
  'post_date' => '2012-12-11 20:23:07',
  'post_date_gmt' => '2012-12-11 20:23:07',
  'post_content' => '',
  'post_title' => 'Man in stripped suit',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'man-in-stripped-suit',
  'post_modified' => '2012-12-12 01:31:20',
  'post_modified_gmt' => '2012-12-12 01:31:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1334',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355275768:32',
    '_thumbnail_id' => '1335',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/man-in-suit2.jpg',
    'total_sales' => '1',
    '_regular_price' => '100',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '100',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_wp_old_slug' => 'lorem-ipsum-4',
    '_post_image_attach_id' => '1335',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1336,
  'post_date' => '2012-12-11 20:24:21',
  'post_date_gmt' => '2012-12-11 20:24:21',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus.

Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna. Suspendisse id erat vel est accumsan rutrum non vitae augue. Nulla euismod facilisis nulla eget gravida.',
  'post_title' => 'Analog Camera',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'analog-camera',
  'post_modified' => '2013-02-05 23:06:35',
  'post_modified_gmt' => '2013-02-05 23:06:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1336',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1337',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/old-camera.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1360105912:32',
    'total_sales' => '7',
    '_regular_price' => '100',
    '_sale_price' => '50',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '50',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1337',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_thumbnail_id\\":[\\"1337\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/old-camera.jpg\\"],\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1360105912:32\\"],\\"total_sales\\":[\\"7\\"],\\"_regular_price\\":[\\"100\\"],\\"_sale_price\\":[\\"50\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"yes\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"50\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1337\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1338,
  'post_date' => '2012-12-11 20:26:55',
  'post_date_gmt' => '2012-12-11 20:26:55',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero. Pellentesque purus diam, sollicitudin vel congue ac, posuere a urna. Suspendisse id erat vel est accumsan rutrum non vitae augue. Nulla euismod facilisis nulla eget gravida.',
  'post_title' => 'Analog Camera Large Viewfinder',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'analog-camera-large-viewfinder',
  'post_modified' => '2012-12-11 20:26:55',
  'post_modified_gmt' => '2012-12-11 20:26:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1338',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355257522:32',
    '_thumbnail_id' => '1339',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/old-camera2.jpg',
    'total_sales' => '5',
    '_regular_price' => '200',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '200',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1339',
    '_wc_rating_count' => 
    array (
      5 => '1',
    ),
    '_wc_average_rating' => '5.00',
    '_wc_review_count' => '1',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355257522:32\\"],\\"_thumbnail_id\\":[\\"1339\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/old-camera2.jpg\\"],\\"total_sales\\":[\\"4\\"],\\"_regular_price\\":[\\"200\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"200\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1339\\"],\\"_wc_rating_count\\":[\\"a:1:{i:5;s:1:\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\";}\\"],\\"_wc_average_rating\\":[\\"5.00\\"],\\"_wc_review_count\\":[\\"1\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'rated-5',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1340,
  'post_date' => '2012-12-11 20:31:51',
  'post_date_gmt' => '2012-12-11 20:31:51',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Analog Camera Kit 45mm',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'analog-camera-kit-45mm',
  'post_modified' => '2012-12-11 20:31:51',
  'post_modified_gmt' => '2012-12-11 20:31:51',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1340',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1443029285:113',
    '_thumbnail_id' => '1341',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/old-camera3.jpg',
    'total_sales' => '11',
    '_regular_price' => '80',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '80',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1341',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1443029285:113\\"],\\"_thumbnail_id\\":[\\"1341\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/old-camera3.jpg\\"],\\"total_sales\\":[\\"11\\"],\\"_regular_price\\":[\\"80\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"yes\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"80\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1341\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1342,
  'post_date' => '2012-12-11 20:32:53',
  'post_date_gmt' => '2012-12-11 20:32:53',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Oranges',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'oranges',
  'post_modified' => '2012-12-11 20:32:53',
  'post_modified_gmt' => '2012-12-11 20:32:53',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1342',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1343',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/orange-juice.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1355257870:32',
    'total_sales' => '2',
    '_regular_price' => '1',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '1',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1343',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1344,
  'post_date' => '2012-12-11 20:34:01',
  'post_date_gmt' => '2012-12-11 20:34:01',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Red Bag',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'red-bag',
  'post_modified' => '2012-12-11 20:34:01',
  'post_modified_gmt' => '2012-12-11 20:34:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1344',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355257945:32',
    '_thumbnail_id' => '1345',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/red-handbag.jpg',
    'total_sales' => '2',
    '_regular_price' => '50',
    '_sale_price' => '40',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '40',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1345',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1346,
  'post_date' => '2012-12-11 20:35:10',
  'post_date_gmt' => '2012-12-11 20:35:10',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus.',
  'post_title' => 'Bowl of Rice',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'bowl-of-rice',
  'post_modified' => '2012-12-11 20:35:10',
  'post_modified_gmt' => '2012-12-11 20:35:10',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1346',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355258017:32',
    '_thumbnail_id' => '1347',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/rice-bowl-and-doll.jpg',
    'total_sales' => '1',
    '_regular_price' => '2',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '2',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1347',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1348,
  'post_date' => '2012-12-11 20:37:04',
  'post_date_gmt' => '2012-12-11 20:37:04',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_title' => 'Green Salad and Tomatoes',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'green-salad-and-tomatoes',
  'post_modified' => '2012-12-11 20:37:04',
  'post_modified_gmt' => '2012-12-11 20:37:04',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1348',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355258121:32',
    '_thumbnail_id' => '1349',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/salad-and-tomatoes.jpg',
    'total_sales' => '4',
    '_regular_price' => '1',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '1',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1349',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355258121:32\\"],\\"_thumbnail_id\\":[\\"1349\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/salad-and-tomatoes.jpg\\"],\\"total_sales\\":[\\"4\\"],\\"_regular_price\\":[\\"1\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"yes\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"1\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1349\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'food',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1350,
  'post_date' => '2012-12-11 20:41:48',
  'post_date_gmt' => '2012-12-11 20:41:48',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.

Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Checkered Shirt',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_name' => 'checkered-shirt',
  'post_modified' => '2012-12-11 20:41:48',
  'post_modified_gmt' => '2012-12-11 20:41:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1350',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355258399:32',
    '_thumbnail_id' => '1351',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/shirt.jpg',
    'total_sales' => '1',
    '_regular_price' => '15',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '15',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1351',
    '_wc_rating_count' => 
    array (
      4 => '1',
    ),
    '_wc_average_rating' => '4.00',
    '_wc_review_count' => '1',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355258399:32\\"],\\"_thumbnail_id\\":[\\"1351\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/shirt.jpg\\"],\\"total_sales\\":[\\"0\\"],\\"_regular_price\\":[\\"15\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"15\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1351\\"],\\"_wc_rating_count\\":[\\"a:1:{i:4;s:1:\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\";}\\"],\\"_wc_average_rating\\":[\\"4.00\\"],\\"_wc_review_count\\":[\\"1\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'rated-4',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1352,
  'post_date' => '2012-12-11 20:51:35',
  'post_date_gmt' => '2012-12-11 20:51:35',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Shooes & Accessories',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'shooes-accessories',
  'post_modified' => '2012-12-11 20:51:35',
  'post_modified_gmt' => '2012-12-11 20:51:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1352',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1353',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/shooes-and-accessories.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1355259033:32',
    'total_sales' => '0',
    '_regular_price' => '50',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '50',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1353',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1354,
  'post_date' => '2012-12-11 20:53:40',
  'post_date_gmt' => '2012-12-11 20:53:40',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.

Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Ski Goggles',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'ski-goggles',
  'post_modified' => '2014-08-25 01:56:43',
  'post_modified_gmt' => '2014-08-25 01:56:43',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1354',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '2',
    '_edit_lock' => '1443561006:113',
    '_thumbnail_id' => '1355',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/ski-goggles.jpg',
    'total_sales' => '13',
    '_regular_price' => '20',
    '_sale_price' => '14',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '14',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1355',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_edit_last\\":[\\"2\\"],\\"_edit_lock\\":[\\"1443561006:113\\"],\\"_thumbnail_id\\":[\\"1355\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/ski-goggles.jpg\\"],\\"total_sales\\":[\\"10\\"],\\"_regular_price\\":[\\"20\\"],\\"_sale_price\\":[\\"14\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"yes\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"14\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1355\\"],\\"_sold_individually\\":[\\"\\"],\\"_product_image_gallery\\":[\\"\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1356,
  'post_date' => '2012-12-11 20:54:44',
  'post_date_gmt' => '2012-12-11 20:54:44',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus.',
  'post_title' => 'Sneakers',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'sneakers',
  'post_modified' => '2012-12-11 20:54:44',
  'post_modified_gmt' => '2012-12-11 20:54:44',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1356',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355259201:32',
    '_thumbnail_id' => '1357',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/sneakers.jpg',
    'total_sales' => '0',
    '_regular_price' => '30',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '30',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1357',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1358,
  'post_date' => '2012-12-11 20:56:04',
  'post_date_gmt' => '2012-12-11 20:56:04',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus.',
  'post_title' => 'Toy Car',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'toy-car',
  'post_modified' => '2012-12-11 20:56:04',
  'post_modified_gmt' => '2012-12-11 20:56:04',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1358',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1359',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/toy-car.jpg',
    '_edit_last' => '32',
    '_edit_lock' => '1355259256:32',
    'total_sales' => '5',
    '_regular_price' => '10',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'yes',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '10',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1359',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_thumbnail_id\\":[\\"1359\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/toy-car.jpg\\"],\\"_edit_last\\":[\\"32\\"],\\"_edit_lock\\":[\\"1355259256:32\\"],\\"total_sales\\":[\\"5\\"],\\"_regular_price\\":[\\"10\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"yes\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"10\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_post_image_attach_id\\":[\\"1359\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_visibility' => 'featured',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1360,
  'post_date' => '2012-12-11 20:56:53',
  'post_date_gmt' => '2012-12-11 20:56:53',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Toy Ship',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'toy-ship',
  'post_modified' => '2012-12-11 20:56:53',
  'post_modified_gmt' => '2012-12-11 20:56:53',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1360',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355259304:32',
    '_thumbnail_id' => '1361',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/toy-ship.jpg',
    'total_sales' => '5',
    '_regular_price' => '50',
    '_sale_price' => '30',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '30',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1361',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1362,
  'post_date' => '2012-12-11 20:57:45',
  'post_date_gmt' => '2012-12-11 20:57:45',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.',
  'post_title' => 'Whine Bottle',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'whine-bottle',
  'post_modified' => '2012-12-11 20:57:45',
  'post_modified_gmt' => '2012-12-11 20:57:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1362',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355259361:32',
    '_thumbnail_id' => '1363',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/whine-bottle-and-glass.jpg',
    'total_sales' => '1',
    '_regular_price' => '20',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '20',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1363',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'gifts',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1364,
  'post_date' => '2012-12-11 20:58:51',
  'post_date_gmt' => '2012-12-11 20:58:51',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Woman holding a clothes hanger',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'woman-holding-a-clothes-hanger',
  'post_modified' => '2012-12-12 01:32:41',
  'post_modified_gmt' => '2012-12-12 01:32:41',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1364',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355275850:32',
    '_thumbnail_id' => '1365',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/woman-holding-hanger.jpg',
    'total_sales' => '0',
    '_regular_price' => '5',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '5',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_wp_old_slug' => 'lorem-ipsum-5',
    '_post_image_attach_id' => '1365',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1366,
  'post_date' => '2012-12-11 20:59:49',
  'post_date_gmt' => '2012-12-11 20:59:49',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros.

Etiam lobortis blandit mi a faucibus.',
  'post_title' => 'Woman in Black Dress',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  'post_name' => 'woman-in-black-dress',
  'post_modified' => '2012-12-11 20:59:49',
  'post_modified_gmt' => '2012-12-11 20:59:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1366',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1355259481:32',
    '_thumbnail_id' => '1367',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/woman-in-dress.jpg',
    'total_sales' => '0',
    '_regular_price' => '50',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '50',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1367',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1368,
  'post_date' => '2012-12-11 21:01:37',
  'post_date_gmt' => '2012-12-11 21:01:37',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi mauris erat, accumsan ac dapibus ut, tincidunt at eros. Etiam lobortis blandit mi a faucibus. Etiam vehicula lectus ut quam mattis luctus. Sed at neque id sapien suscipit viverra in non sapien. Curabitur sed tellus libero.',
  'post_title' => 'Woman in Blue Dress',
  'post_excerpt' => '',
  'post_name' => 'woman-in-blue-dress',
  'post_modified' => '2012-12-20 21:57:31',
  'post_modified_gmt' => '2012-12-20 21:57:31',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1368',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_last' => '32',
    '_edit_lock' => '1444065539:115',
    '_thumbnail_id' => '1369',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/woman-in-dress2.jpg',
    'total_sales' => '3',
    '_regular_price' => '60',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '60',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_post_image_attach_id' => '1369',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1370,
  'post_date' => '2012-12-11 21:02:42',
  'post_date_gmt' => '2012-12-11 21:02:42',
  'post_content' => 'You may use WooCommerce for affiliate products. This is an example.',
  'post_title' => 'Affiliate Product',
  'post_excerpt' => 'This is an example of WooCommerce affiliate product.',
  'post_name' => 'woman-shopping',
  'post_modified' => '2015-05-05 17:04:52',
  'post_modified_gmt' => '2015-05-05 17:04:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?post_type=product&#038;p=1370',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_thumbnail_id' => '1371',
    'post_image' => 'https://themify.me/demo/themes/pinshop/files/2012/12/woman-shopping.jpg',
    '_edit_last' => '2',
    '_edit_lock' => '1501774749:115',
    'total_sales' => '0',
    '_regular_price' => '50',
    '_tax_status' => 'taxable',
    '_visibility' => 'visible',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_price' => '50',
    '_stock_status' => 'instock',
    '_backorders' => 'no',
    '_manage_stock' => 'no',
    '_wp_old_slug' => 'lorem-ipsum-6',
    '_post_image_attach_id' => '1371',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_url' => 'https://themify.me',
    '_button_text' => 'Go Buy Now',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_themify_builder_settings_json' => '{\\"_thumbnail_id\\":[\\"1371\\"],\\"post_image\\":[\\"https://themify.me/demo/themes/pinshop/files/2012/12/woman-shopping.jpg\\"],\\"_edit_last\\":[\\"2\\"],\\"_edit_lock\\":[\\"1460147235:115\\"],\\"total_sales\\":[\\"0\\"],\\"_regular_price\\":[\\"50\\"],\\"_sale_price\\":[\\"\\"],\\"_tax_status\\":[\\"taxable\\"],\\"_tax_class\\":[\\"\\"],\\"_visibility\\":[\\"visible\\"],\\"_purchase_note\\":[\\"\\"],\\"_featured\\":[\\"no\\"],\\"_weight\\":[\\"\\"],\\"_length\\":[\\"\\"],\\"_width\\":[\\"\\"],\\"_height\\":[\\"\\"],\\"_sku\\":[\\"\\"],\\"_product_attributes\\":[\\"a:0:{}\\"],\\"_downloadable\\":[\\"no\\"],\\"_virtual\\":[\\"no\\"],\\"_sale_price_dates_from\\":[\\"\\"],\\"_sale_price_dates_to\\":[\\"\\"],\\"_price\\":[\\"50\\"],\\"_stock\\":[\\"\\"],\\"_stock_status\\":[\\"instock\\"],\\"_backorders\\":[\\"no\\"],\\"_manage_stock\\":[\\"no\\"],\\"_wp_old_slug\\":[\\"lorem-ipsum-6\\"],\\"_post_image_attach_id\\":[\\"1371\\"],\\"_sold_individually\\":[\\"\\"],\\"_upsell_ids\\":[\\"a:0:{}\\"],\\"_crosssell_ids\\":[\\"a:0:{}\\"],\\"_product_url\\":[\\"https://themify.me\\"],\\"_button_text\\":[\\"Go Buy Now\\"],\\"_product_image_gallery\\":[\\"\\"],\\"_wc_rating_count\\":[\\"a:0:{}\\"],\\"_wc_average_rating\\":[\\"0\\"],\\"_wc_review_count\\":[\\"0\\"]}',
  ),
  'tax_input' => 
  array (
    'product_type' => 'external',
    'product_cat' => 'clothes',
  ),
  'has_thumbnail' => true,
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1517,
  'post_date' => '2012-12-18 23:41:41',
  'post_date_gmt' => '2012-12-18 23:41:41',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1517',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1517',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '1271',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 179,
  'post_date' => '2012-12-05 23:21:18',
  'post_date_gmt' => '2012-12-05 23:21:18',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '179',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/2012/12/05/179/',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '121',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 180,
  'post_date' => '2012-12-05 23:21:18',
  'post_date_gmt' => '2012-12-05 23:21:18',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '180',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/2012/12/05/180/',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '179',
    '_menu_item_object_id' => '128',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 181,
  'post_date' => '2012-12-05 23:21:18',
  'post_date_gmt' => '2012-12-05 23:21:18',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '181',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/2012/12/05/181/',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '179',
    '_menu_item_object_id' => '126',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 182,
  'post_date' => '2012-12-05 23:21:18',
  'post_date_gmt' => '2012-12-05 23:21:18',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '182',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/2012/12/05/182/',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '179',
    '_menu_item_object_id' => '123',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1520,
  'post_date' => '2012-12-18 23:52:37',
  'post_date_gmt' => '2012-12-18 23:52:37',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1520',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1520',
  'menu_order' => 6,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '179',
    '_menu_item_object_id' => '1288',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1521,
  'post_date' => '2012-12-18 23:52:37',
  'post_date_gmt' => '2012-12-18 23:52:37',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1521',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1521',
  'menu_order' => 7,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '179',
    '_menu_item_object_id' => '1285',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1522,
  'post_date' => '2012-12-18 23:52:37',
  'post_date_gmt' => '2012-12-18 23:52:37',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1522',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1522',
  'menu_order' => 8,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '179',
    '_menu_item_object_id' => '1282',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 1519,
  'post_date' => '2012-12-18 23:52:37',
  'post_date_gmt' => '2012-12-18 23:52:37',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1519',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 121,
  'guid' => 'https://themify.me/demo/themes/pinshop/?p=1519',
  'menu_order' => 9,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '179',
    '_menu_item_object_id' => '1451',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 185,
  'post_date' => '2012-12-05 23:21:18',
  'post_date_gmt' => '2012-12-05 23:21:18',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '185',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/2012/12/05/185/',
  'menu_order' => 10,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '152',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 183,
  'post_date' => '2012-12-05 23:21:18',
  'post_date_gmt' => '2012-12-05 23:21:18',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '183',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/pinshop/2012/12/05/183/',
  'menu_order' => 11,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '139',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}

$post = array (
  'ID' => 184,
  'post_date' => '2012-12-05 23:21:18',
  'post_date_gmt' => '2012-12-05 23:21:18',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '184',
  'post_modified' => '2015-01-26 23:01:55',
  'post_modified_gmt' => '2015-01-26 23:01:55',
  'post_content_filtered' => '',
  'post_parent' => 139,
  'guid' => 'https://themify.me/demo/themes/pinshop/2012/12/05/184/',
  'menu_order' => 12,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '183',
    '_menu_item_object_id' => '146',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-nav',
  ),
);

if( ERASEDEMO ) {
	themify_undo_import_post( $post );
} else {
	themify_import_post( $post );
}


function themify_import_get_term_id_from_slug( $slug ) {
	$menu = get_term_by( "slug", $slug, "nav_menu" );
	return is_wp_error( $menu ) ? 0 : (int) $menu->term_id;
}

	$widgets = get_option( "widget_themify-feature-posts" );
$widgets[1002] = array (
  'title' => 'Recent Posts',
  'category' => '0',
  'show_count' => '3',
  'show_date' => NULL,
  'show_thumb' => NULL,
  'show_excerpt' => 'on',
  'hide_title' => NULL,
  'thumb_width' => '50',
  'thumb_height' => '50',
  'excerpt_length' => '55',
);
update_option( "widget_themify-feature-posts", $widgets );

$widgets = get_option( "widget_themify-twitter" );
$widgets[1003] = array (
  'title' => 'Latest Tweets',
  'username' => 'themify',
  'show_count' => '3',
  'hide_timestamp' => NULL,
  'show_follow' => NULL,
  'follow_text' => '→ Follow me',
  'type' => '0',
  'timeline_height' => '400',
  'timeline_width' => '300',
  'grid_embed_code' => '',
  'hide_footer' => NULL,
  'include_retweets' => NULL,
  'exclude_replies' => NULL,
);
update_option( "widget_themify-twitter", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1004] = array (
  'title' => '',
  'show_link_name' => NULL,
  'thumb_width' => '',
  'thumb_height' => '',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'wp_inactive_widgets' => 
  array (
    0 => 'themify-feature-posts-1002',
  ),
  'sidebar-main' => 
  array (
    0 => 'themify-twitter-1003',
  ),
  'social-widget' => 
  array (
    0 => 'themify-social-links-1004',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-nav" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );


$homepage = get_posts( array( 'name' => 'shop', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			
	ob_start(); ?>a:56:{s:16:"setting-page_404";s:1:"0";s:21:"setting-webfonts_list";s:11:"recommended";s:22:"setting-default_layout";s:12:"sidebar-none";s:27:"setting-default_post_layout";s:9:"list-post";s:30:"setting-default_layout_display";s:7:"content";s:25:"setting-default_more_text";s:4:"More";s:21:"setting-index_orderby";s:4:"date";s:19:"setting-index_order";s:4:"DESC";s:31:"setting-image_post_feature_size";s:5:"blank";s:32:"setting-default_page_post_layout";s:8:"sidebar1";s:38:"setting-image_post_single_feature_size";s:5:"blank";s:27:"setting-default_page_layout";s:8:"sidebar1";s:53:"setting-customizer_responsive_design_tablet_landscape";s:4:"1024";s:43:"setting-customizer_responsive_design_tablet";s:3:"768";s:43:"setting-customizer_responsive_design_mobile";s:3:"480";s:33:"setting-mobile_menu_trigger_point";s:4:"1200";s:24:"setting-gallery_lightbox";s:8:"lightbox";s:31:"setting-lightbox_content_images";s:2:"on";s:27:"setting-script_minification";s:7:"disable";s:27:"setting-page_builder_expiry";s:1:"2";s:19:"setting-entries_nav";s:8:"numbered";s:18:"setting-more_posts";s:8:"infinite";s:22:"setting-footer_widgets";s:17:"footerwidget-3col";s:19:"setting-shop_layout";s:12:"sidebar-none";s:23:"setting-products_layout";s:5:"grid4";s:23:"setting-hide_shop_title";s:2:"on";s:29:"setting-single_product_layout";s:21:"sidebar1 sidebar-left";s:30:"setting-related_products_limit";s:1:"3";s:27:"setting-shop_archive_layout";s:8:"sidebar1";s:30:"setting-product_slider_enabled";s:2:"on";s:37:"setting-product_slider_posts_category";s:1:"0";s:30:"setting-product_slider_visible";s:1:"4";s:27:"setting-product_slider_auto";s:1:"0";s:29:"setting-product_slider_scroll";s:1:"1";s:28:"setting-product_slider_speed";s:3:"300";s:27:"setting-product_slider_wrap";s:3:"yes";s:36:"setting-shop_search_option_preselect";s:4:"post";s:27:"setting-global_feature_size";s:5:"large";s:22:"setting-link_icon_type";s:10:"image-icon";s:32:"setting-link_type_themify-link-0";s:10:"image-icon";s:33:"setting-link_title_themify-link-0";s:7:"Twitter";s:32:"setting-link_link_themify-link-0";s:26:"http://twitter.com/themify";s:31:"setting-link_img_themify-link-0";s:95:"https://themify.me/demo/themes/pinshop/wp-content/themes/pinshop/themify/img/social/twitter.png";s:32:"setting-link_type_themify-link-1";s:10:"image-icon";s:33:"setting-link_title_themify-link-1";s:8:"Facebook";s:32:"setting-link_link_themify-link-1";s:27:"http://facebook.com/themify";s:31:"setting-link_img_themify-link-1";s:96:"https://themify.me/demo/themes/pinshop/wp-content/themes/pinshop/themify/img/social/facebook.png";s:32:"setting-link_type_themify-link-4";s:10:"image-icon";s:33:"setting-link_title_themify-link-4";s:9:"Pinterest";s:32:"setting-link_link_themify-link-4";s:21:"http://pinterest.com/";s:31:"setting-link_img_themify-link-4";s:97:"https://themify.me/demo/themes/pinshop/wp-content/themes/pinshop/themify/img/social/pinterest.png";s:22:"setting-link_field_ids";s:103:"{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-4":"themify-link-4"}";s:23:"setting-link_field_hash";s:1:"5";s:30:"setting-page_builder_is_active";s:6:"enable";s:46:"setting-page_builder_animation_parallax_scroll";s:6:"mobile";s:4:"skin";s:89:"https://themify.me/demo/themes/pinshop/wp-content/themes/pinshop/themify/img/non-skin.gif";}<?php $themify_data = unserialize( ob_get_clean() );

	// fix the weird way "skin" is saved
	if( isset( $themify_data['skin'] ) ) {
		$parsed_skin = parse_url( $themify_data['skin'], PHP_URL_PATH );
		$basedir_skin = basename( dirname( $parsed_skin ) );
		$themify_data['skin'] = trailingslashit( get_template_directory_uri() ) . 'skins/' . $basedir_skin . '/style.css';
	}

	themify_set_data( $themify_data );
	
}
themify_do_demo_import();